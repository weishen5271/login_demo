package com.example.demo.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>类描述：。</p>
 *
 * @author 沈伟 [shenwei]。
 * @version v1.0.0.1。
 * @since JDK1.8。
 * <p>创建日期：2020/10/9 0009 17:27。</p>
 */
@RestController
@RequestMapping("user")
public class TestController {


    @RequestMapping("/test")
    public String test(){
        return "test";
    }
}
